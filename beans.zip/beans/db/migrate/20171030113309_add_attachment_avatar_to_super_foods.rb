class AddAttachmentAvatarToSuperFoods < ActiveRecord::Migration[5.1]
  def self.up
    change_table :super_foods do |t|
      t.attachment :avatar
    end
  end

  def self.down
    remove_attachment :super_foods, :avatar
  end
end
