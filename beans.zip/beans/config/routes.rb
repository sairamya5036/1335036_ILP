Rails.application.routes.draw do
  get 'learnmore/view'

  mount Rapidfire::Engine => "/rapidfire"
 # GET /rapidfire/surveys/<survey-id>/results
 get 'learnmore/view'
  root to: 'home#welcome'
  resources :super_foods
  resources :categories
  get 'home/cust'
  get 'users/index'
  get 'home/start'

  get 'home/dispscore'

  get 'home/dispfinal'

  get 'home/welcome'

  get 'home/aboutus'
  get 'learnmore/view'
  get 'home/alley'
  get 'home/boulevard'
  get 'home/corniche'
  get 'home/countrylane'
  get 'home/street'
devise_scope :user do
get '/users/sign_out' , to: 'devise/sessions#destroy'
end
  devise_for :users
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
