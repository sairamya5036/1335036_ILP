require "application_system_test_case"

class CategoriesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit categories_url
  #
  #   assert_selector "h1", text: "Category"
  # end
end
