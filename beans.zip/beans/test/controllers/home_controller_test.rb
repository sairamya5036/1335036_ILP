require 'test_helper'

class HomeControllerTest < ActionDispatch::IntegrationTest
  test "should get welcome" do
    get home_welcome_url
    assert_response :success
  end

  test "should get cust" do
    get home_cust_url
    assert_response :success
  end

  test "should get start" do
    get home_start_url
    assert_response :success
  end

  test "should get dispscore" do
    get home_dispscore_url
    assert_response :success
  end

  test "should get dispfinal" do
    get home_dispfinal_url
    assert_response :success
  end

end
