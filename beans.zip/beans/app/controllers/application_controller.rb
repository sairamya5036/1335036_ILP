class ApplicationController < ActionController::Base
  protect_from_forgery with: :exception, except:[ :view]
def view
  end

def can_administer?
      current_user.try(:role?)
    end

end
