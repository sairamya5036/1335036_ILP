require 'test_helper'

class SuperFoodsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @super_food = super_foods(:one)
  end

  test "should get index" do
    get super_foods_url
    assert_response :success
  end

  test "should get new" do
    get new_super_food_url
    assert_response :success
  end

  test "should create super_food" do
    assert_difference('SuperFood.count') do
      post super_foods_url, params: { super_food: { category_id: @super_food.category_id, name: @super_food.name, price: @super_food.price, quantity: @super_food.quantity } }
    end

    assert_redirected_to super_food_url(SuperFood.last)
  end

  test "should show super_food" do
    get super_food_url(@super_food)
    assert_response :success
  end

  test "should get edit" do
    get edit_super_food_url(@super_food)
    assert_response :success
  end

  test "should update super_food" do
    patch super_food_url(@super_food), params: { super_food: { category_id: @super_food.category_id, name: @super_food.name, price: @super_food.price, quantity: @super_food.quantity } }
    assert_redirected_to super_food_url(@super_food)
  end

  test "should destroy super_food" do
    assert_difference('SuperFood.count', -1) do
      delete super_food_url(@super_food)
    end

    assert_redirected_to super_foods_url
  end
end
