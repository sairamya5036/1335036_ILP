class HomeController < ApplicationController
  before_action :authenticate_user!
  def welcome
  end

  def cust
  end

  def start
  end

  def dispscore
 # @user=User.find(params[:id])


  
  
  end

  def dispfinal
  end

  def aboutus
  end

  def alley
@super_food=SuperFood.all
  end

  def boulevard
@super_food=SuperFood.all
  end

  def corniche
# @categories=Category.all
 @super_food=SuperFood.all
  end
  
  def countrylane
@super_food=SuperFood.all
  end  
 
  def street
@super_food=SuperFood.all
  end

  def index
  end

end
