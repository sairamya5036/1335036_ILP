require 'test_helper'

class LearnmoreControllerTest < ActionDispatch::IntegrationTest
  test "should get view" do
    get learnmore_view_url
    assert_response :success
  end

end
