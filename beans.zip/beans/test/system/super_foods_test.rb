require "application_system_test_case"

class SuperFoodsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit super_foods_url
  #
  #   assert_selector "h1", text: "SuperFood"
  # end
end
