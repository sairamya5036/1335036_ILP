class LearnmoreController < ApplicationController
   before_action :authenticate_user!  ,except:[:view]
  def view
  	 render('learnmore/view')
  end
end
